# is20-server
REST server demo in Spring for IS course
