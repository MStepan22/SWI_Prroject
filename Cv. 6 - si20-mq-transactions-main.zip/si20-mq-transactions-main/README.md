# si20-mq-transactions
Message Queue and distributed transactions examples for SI course

## Running a local message queue (on Windows)

* Download Apache ActiveMQ Artemis binary from https://activemq.apache.org/components/artemis/download/
* Unpack the directory, go to `bin` subdirectory, run command `artemis.cmd create |path to a new directory of your choice|`
* Answer the questions
* Go to `|path to a new directory of your choice|\bin` and run command `artemis.cmd run`
