package si20.demotransactions.proj1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proj1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
